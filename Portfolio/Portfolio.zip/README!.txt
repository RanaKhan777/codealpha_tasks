How to Open the Website

Option 1: Open Locally

Download or clone the project repository to your computer.

Navigate to the project folder.

Open the index.html file in your preferred web browser.

You can double-click the file.

Or right-click and select Open with → Browser.


Option 2: Run with Live Server (Recommended)

If you have Visual Studio Code installed, you can use the Live Server extension for a better experience:

Open the project folder in VS Code.

Install the Live Server extension (if not installed already).

Right-click on index.html and select Open with Live Server.